-- Add columns that calculate values
-- Exercise Files > Chapter 7 > Math_Start.sql
SELECT SKU,
    ProductName,
    CategoryID,
    Size,
    Price
FROM products.products;
